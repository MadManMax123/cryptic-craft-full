package com.satyaki.escaperoom.commands;

import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class SuitUpCommand implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {

        if (!(sender instanceof Player player)) {
            sender.sendMessage("Only players can use this command.");
            return true;
        }

        // 🔐 Admin only
        if (!player.isOp()) {
            player.sendMessage("§cNo permission.");
            return true;
        }

        // 🛡️ Clear inventory first (optional but clean)
        player.getInventory().clear();

        // ===== NETHERITE ARMOR =====
        giveArmor(player, Material.NETHERITE_HELMET);
        giveArmor(player, Material.NETHERITE_CHESTPLATE);
        giveArmor(player, Material.NETHERITE_LEGGINGS);
        giveArmor(player, Material.NETHERITE_BOOTS);

        // ⚔️ SWORD
        player.getInventory().addItem(enchant(new ItemStack(Material.NETHERITE_SWORD)));

        // 🪓 AXE
        player.getInventory().addItem(enchant(new ItemStack(Material.NETHERITE_AXE)));

        // 🛡️ SHIELD
        player.getInventory().addItem(new ItemStack(Material.SHIELD));

        // 🍎 GOLDEN APPLES (64)
        player.getInventory().addItem(new ItemStack(Material.GOLDEN_APPLE, 64));

        // 🧿 ENDER PEARLS (16)
        player.getInventory().addItem(new ItemStack(Material.ENDER_PEARL, 16));

        player.sendMessage("§aYou are now fully suited up!");
        return true;
    }

    // ===== helpers =====

    private void giveArmor(Player player, Material mat) {
        player.getInventory().addItem(enchant(new ItemStack(mat)));
    }

    private ItemStack enchant(ItemStack item) {
        ItemMeta meta = item.getItemMeta();

        meta.addEnchant(Enchantment.PROTECTION, 4, true);
        meta.addEnchant(Enchantment.UNBREAKING, 3, true);
        meta.addEnchant(Enchantment.MENDING, 1, true);

        // weapon-only enchants
        if (item.getType().toString().contains("SWORD")) {
            meta.addEnchant(Enchantment.SHARPNESS, 5, true);
        }

        if (item.getType().toString().contains("AXE")) {
            meta.addEnchant(Enchantment.SHARPNESS, 5, true);
        }

        item.setItemMeta(meta);
        return item;
    }
}